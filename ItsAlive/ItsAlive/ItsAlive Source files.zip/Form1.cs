﻿using System;
using System.ComponentModel;
using System.Net.Mail;
using System.Net.NetworkInformation;
using System.Text;
using System.Windows.Forms;

namespace ItsAlive
{
    public partial class Form1 : Form
    {
        private BackgroundWorker _pingBw = new BackgroundWorker(); //Ping background worker
        private BackgroundWorker _emailBw = new BackgroundWorker(); //Email Background Worker

        private bool _router = false; //Router Status bool
        private bool _server = false; // server status bool
        private bool _mailSent = false; //Email status bool
        private int _pings = 0; // num of pings 
        private int _downs = 0; //Counts number of down pings

        public Form1()
        {
            InitializeComponent();
            //Config background worker for the pings
            _pingBw.WorkerReportsProgress = true;
            _pingBw.WorkerSupportsCancellation = true;
            _pingBw.DoWork += new DoWorkEventHandler(ping_bw_DoWork);
            _pingBw.ProgressChanged += new ProgressChangedEventHandler(ping_bw_ProgressChanged);
            _pingBw.RunWorkerCompleted += new RunWorkerCompletedEventHandler(ping_bw_RunWorkerCompleted);
            //Config background worker for email
            _emailBw.WorkerReportsProgress = true;
            _emailBw.WorkerSupportsCancellation = false;
            _emailBw.DoWork += new DoWorkEventHandler(email_bw_DoWork);
            _emailBw.ProgressChanged += new ProgressChangedEventHandler(email_bw_ProgressChanged);
            _emailBw.RunWorkerCompleted += new RunWorkerCompletedEventHandler(email_bw_RunWorkerCompleted);
        }

        //Minimize to system tray instead of taskbar
        private void frmMain_Resize(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Minimized)
            {
                notifyIcon1.Visible = true;
                Hide();
            }
        }

        //Click system tary icon to maximize
        private void notifyIcon_Click(object sender, EventArgs e)
        {
            Show();
            WindowState = FormWindowState.Normal;
            notifyIcon1.Visible = false;
        }

        //Pings the target ip and returns the reply
        private PingReply PingIp(string ip)
        {
            Ping pingSender = new Ping();
            PingOptions options = new PingOptions();
            pingSender.PingCompleted += new PingCompletedEventHandler(PingCompletedCallback);
            options.DontFragment = true;
            string data = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
            byte[] buffer = Encoding.ASCII.GetBytes(data);
            int timeout = 60;
            try
            {
                PingReply reply = pingSender.Send(ip, timeout, buffer, options);
                return reply;
            }
            catch (PingException e)
            {
                Invoke(new Action(() => { label7.Text = "Ping error: " + e.ToString(); }));
                _pingBw.CancelAsync();
                throw;
            }
        }

        private void PingCompletedCallback(object sender, PingCompletedEventArgs e)
        {
            // If an error occurred, display the exception to the user. 
            if (e.Error != null)
            {
                label6.Text = "Ping failed";
            }
        }

        //Calls pingIP() and will check the returnd ping's Status and set a boolean value for each device
        private void Pinger()
        {
            PingReply ping1 = PingIp("192.168.1.1");
            if (ping1.Status == IPStatus.Success)
            {
                _server = true;
            }
            else
            {
                _server = false;
            }
            PingReply ping2 = PingIp("192.168.1.254");
            if (ping2.Status == IPStatus.Success)
            {
                _router = true;
            }
            else
            {
                _router = false;
            }
        }


        //Start the ping background worker
        private void button1_Click(object sender, EventArgs e)
        {
            if (_pingBw.IsBusy != true)
            {
                _router = false;
                _server = false;
                label6.Text = "Started";
                button1.Enabled = false;
                button2.Enabled = true;
                _pingBw.RunWorkerAsync();
            }
        }

        //Stop the ping background worker
        private void button2_Click(object sender, EventArgs e)
        {
            if (_pingBw.WorkerSupportsCancellation)
            {
                button1.Enabled = true;
                button2.Enabled = false;
                _mailSent = false;
                _pings = 0;
                _pingBw.CancelAsync();
            }
        }

        //Call Pinger(), report the progress to update the labels then sleep
        private void ping_bw_DoWork(object sender, DoWorkEventArgs e)
        {
            BackgroundWorker worker = sender as BackgroundWorker;

            while (true)
            {
                if ((worker.CancellationPending == true))
                {
                    e.Cancel = true;
                    break;
                }
                else
                {
                    Pinger();

                    worker.ReportProgress(1);

                    System.Threading.Thread.Sleep(60000);
                }
            }
        }

        //Ping worker done, not that it should ever finish
        private void ping_bw_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if ((e.Cancelled == true))
            {
                label6.Text = "Stopped!";
            }

            else if (!(e.Error == null))
            {
                label6.Text = ("Error: " + e.Error.Message);
            }

            else
            {
                label6.Text = "Done!";
            }
        }

        //Used to update the labels for the status
        private void ping_bw_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            //If server is up and a email has been sent reset that an email has been sent,
            //else if server is down router is up and has been down for 2 pings an email will be sent
            if (_server)
            {
                label3.Text = "Up";
                _downs = 0;
                if (_mailSent)
                {
                    _mailSent = false;
                    label5.Text = "";
                }
            }
            else
            {
                label3.Text = "Down";
                _downs++;
                if (_emailBw.IsBusy != true)
                {
                    if (_mailSent == false && _router && _downs == 2)
                    {
                        _emailBw.RunWorkerAsync();
                        label5.Text = "starting";
                    }
                }
            }

            if (_router)
            {
                label4.Text = "Up";
                label5.Text = "";
            }
            else
            {
                label4.Text = "Down";
                label5.Text = "No Connection";
            }

            _pings++;
            label7.Text = _pings.ToString();
        }

        //Worker for Email
        private void email_bw_DoWork(object sender, DoWorkEventArgs e)
        {
            BackgroundWorker worker = sender as BackgroundWorker;

            Email mail = new Email();
            if (_server == false && _router)
            {
                mail.SendEmail("192.168.1.1");
                _mailSent = true;
                worker.ReportProgress(1);
                System.Threading.Thread.Sleep(1000);
            }
        }

        private void email_bw_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (!(e.Error == null))
            {
                label5.Text = ("Error: " + e.Error.Message);
            }

            else if (_mailSent == true)
            {
                label5.Text = "Sent!";
            }
        }

        private void email_bw_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            label5.Text = "Sending";
        }
    }

    public class Email
    {
        public void SendEmail(String name)
        {
            SmtpClient client = new SmtpClient
            {
                Port = 587,
                Host = "smtp.gmail.com",
                EnableSsl = true,
                Timeout = 10000,
                DeliveryMethod = SmtpDeliveryMethod.Network,
                UseDefaultCredentials = false,
                Credentials = new System.Net.NetworkCredential("user@gmail.com", "Pass")
            };
            MailMessage mm = new MailMessage("areialace@gmail.com", "areialace@gmail.com", name + " is down",
                name + " is down");
            mm.BodyEncoding = UTF8Encoding.UTF8;
            mm.DeliveryNotificationOptions = DeliveryNotificationOptions.OnFailure;
            client.Send(mm);
        }
    }
}